({
	rendering: function(cmp, event, helper) {
		headerTag = document.getElementsByTagName("header");
        $A.util.addClass(headerTag,'slds-hide');
	}
})